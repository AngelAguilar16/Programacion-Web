<?php 

include 'layouts/main.php';

head();

?>
  <div class="row">
    <div class="col">
     
    </div>
    <div class="col-6">
        <div class="content" id="content">
                        
        </div>      
    </div>
    <div class="col">
        <div class="list-group mt-5" id="usuarios">
        </div>
    </div>
  </div>


<?php foot(); ?>