<?php

function head(){
   
?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" href="/resources/css/bootstrap.min.css">
            <link rel="stylesheet" href="/resources/css/app.css">
            <title>PHP & JS CRUD</title>
        </head>
        <body>

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="/">WORLD</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>	
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="/resources/views/ciudades.php">Ciudades<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Paises</a>
                    </li>
                </ul>
                <ul class="navbar-nav navbar-right">
                    <li class="nav-item">
                        <a href="#" class="nav-link disabled">Iniciar sesión</a>
                    </li>
                </ul>
            </div>
        </nav>

    <?php
    

}

function scripts(){
    ?>
        <!-- <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js"></script> -->
        <script src="../js/jquery.min.js"></script>	
        <script src="../js/bootstrap.min.js"></script>	
        <script src="../js/app.js"></script>        

    <?php
}


function footer($banner = 'PHP | JS | CRUD'){
    ?>

        <footer>
	        <small><?=$banner?></small>
        </footer>
    </body>
    </html>
    <?php
}