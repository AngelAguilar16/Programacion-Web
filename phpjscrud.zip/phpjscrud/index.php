<?php 

include 'resources/views/layouts/main.php';

head();

?>


<div class="container">
	<h1>BIENVENIDO</h1>
</div>


<script type="text/javascript">

</script>

<?php
	footer();
?>